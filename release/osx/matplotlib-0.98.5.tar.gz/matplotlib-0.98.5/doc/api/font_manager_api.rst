***********************
matplotlib font_manager
***********************

:mod:`matplotlib.font_manager`
==============================

.. automodule:: matplotlib.font_manager
   :members:
   :undoc-members:
   :show-inheritance:

:mod:`matplotlib.fontconfig_pattern`
====================================

.. automodule:: matplotlib.fontconfig_pattern
   :members:
   :undoc-members:
   :show-inheritance:


